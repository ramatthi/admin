import { adminpricingPlugin } from './plugin';

describe('adminpricing', () => {
  it('should export plugin', () => {
    expect(adminpricingPlugin).toBeDefined();
  });
});
