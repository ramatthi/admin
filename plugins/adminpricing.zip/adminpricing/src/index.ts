export { adminpricingPlugin, AdminpricingPage } from './plugin';
